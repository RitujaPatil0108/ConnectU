// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:connectuapp/signin_screen.dart';

// class FirebaseServices {
//   final _auth = FirebaseAuth.instance;
//   final _googleSignIn = GoogleSignIn();

//   signInWithGoogle() async {
//     try {
//       final GoogleSignInAccount? googleSignInAccount =
//           await _googleSignIn.signIn();
//       if (googleSignInAccount != null) {
//         final GoogleSignInAuthentication googleSignInAuthentication =
//             await googleSignInAccount.authentication;
//         final AuthCredential authCredential = GoogleAuthProvider.credential(
//             accessToken: googleSignInAuthentication.accessToken,
//             idToken: googleSignInAuthentication.idToken);
//         await _auth.signInWithCredential(authCredential);
//       }
//     } on FirebaseAuthException catch (e) {
//       print(e.message);
//       throw e;
//     }
//   }

//   googleSignOut() async {
//     await _auth.signOut();
//     await _googleSignIn.signOut();
//   }
// }