import 'package:connectuapp/screens/gmap_screen.dart';
import 'package:connectuapp/screens/googlemap_screen.dart';
import 'package:connectuapp/screens/home_screen.dart';
import 'package:connectuapp/screens/userlist_screen.dart';
import 'package:flutter/material.dart';
class BottomNavigation extends StatelessWidget 
{
  const BottomNavigation({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) 
  {
    return Container(
      decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
          Color.fromRGBO(0, 171, 239, 1),
          Color.fromRGBO(169, 82, 160, 1)
        ], begin: Alignment.centerLeft, end: Alignment.centerRight)),
      child: BottomNavigationBar(
      backgroundColor: Colors.transparent,
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.search_outlined, color: Colors.white, size: 35,), label: ''),
        BottomNavigationBarItem(icon: Icon(Icons.home_outlined, size: 35,), label: ''),
        BottomNavigationBarItem(icon: Icon(Icons.location_city_outlined, color: Colors.white, size: 35,), label: '')
      ],
      onTap: (int index) {
        switch (index) {
          case 0:
            //Navigator.push(context, MaterialPageRoute(builder: (context) => SearchScreen()));
            Navigator.push(context, MaterialPageRoute(builder: (context) => UserList()));
            break;
          case 1:
            Navigator.push(context, MaterialPageRoute(builder: (context) => HomeScreen()));
            break;
          case 2:
            //Navigator.push(context, MaterialPageRoute(builder: (context) => ChatScreen()));
            Navigator.push(context, MaterialPageRoute(builder: (context) => GMapScreen()));
            break;
        }
      },
    ));
  }
}