import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectuapp/main.dart';
import 'package:connectuapp/models/ChatRoomModel.dart';
import 'package:connectuapp/models/Users.dart';
import 'package:connectuapp/screens/ChatRoomPage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class UserList extends StatefulWidget {
  late final Users userModel;
  late final User firebaseUser;

  @override
  State<UserList> createState() => _UserListState();
}

class _UserListState extends State<UserList> {
  String uid = FirebaseAuth.instance.currentUser!.uid.toString();
  String email = FirebaseAuth.instance.currentUser!.email.toString();


  Future<ChatRoomModel?> getChatroomModel(Users targetUser) async {
    ChatRoomModel? chatRoom;

    QuerySnapshot snapshot = await FirebaseFirestore.instance.collection("chatrooms").where("participants.${widget.userModel.uid}", isEqualTo: true).where("participants.${targetUser.uid}", isEqualTo: true).get();

    if(snapshot.docs.length > 0) {
      // Fetch the existing one
      var docData = snapshot.docs[0].data();
      ChatRoomModel existingChatroom = ChatRoomModel.fromMap(docData as Map<String, dynamic>);

      chatRoom = existingChatroom;
    }
    else {
      // Create a new one
      ChatRoomModel newChatroom = ChatRoomModel(
        chatroomid: uuid.v1(),
        lastMessage: "",
        participants: {
          widget.userModel.uid.toString(): true,
          targetUser.uid.toString(): true,
        },
      );

      await FirebaseFirestore.instance.collection("chatrooms").doc(newChatroom.chatroomid).set(newChatroom.toMap());

      chatRoom = newChatroom;

      log("New Chatroom Created!");
    }

    return chatRoom;
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 118, 45, 130),
        title: Text("Users"),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .where('uid', isEqualTo: uid)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
          List<Users> users1 = [];
          snapshot.data?.docs.forEach((doc) {
            Users user = Users.fromMap(doc.data() as Map<String, dynamic>);
            users1.add(user);
            print("Options of User: ");
            print(user.options);
            //print("USer 1 **********");
            //print(users1[0].user.)
          });
          print("**********************");
          print(users1);
          late Users usernew;
          users1.forEach((element) {
            print(element.options);
            usernew = element;
          });
          print(usernew);
          print("Usernew Options: ");
          print(usernew.options);

          return StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('users')
                //.where('email', isNotEqualTo: email)
                .where('options', isEqualTo: usernew.options)
                .snapshots(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return Center(
                  child: CircularProgressIndicator(),
                );
              }
              List<Users> users = [];
              snapshot.data?.docs.forEach((doc) {
                Users user = Users.fromMap(doc.data() as Map<String, dynamic>);
                users.add(user);
              });
              return ListView.builder(
                  shrinkWrap: true,
                  itemCount: users.length,
                  itemBuilder: (context, index) {
                    Users user = users[index];
                    return ListTile(
                      // onTap: (){
                      //   Navigator.push(context, MaterialPageRoute(builder: (context){
                      //     return ChatRoomPage();
                      //   }));
                      // },
                      leading: CircleAvatar(
                        backgroundImage: NetworkImage(user.imageUrl),
                        radius: 50,
                      ),
                      title: Text(user.username),
                      subtitle: Text(user.name), // location
                      trailing: ElevatedButton.icon(
                        
                        onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context){
                          return ChatRoomPage();
                        }));
                        },
                        icon: Icon(
                          Icons.message_sharp,
                          //size: 24.0,
                        ),
                        label: Text(''),
                      ),
                    );
                  });
            },
          );
        },
      ),
    );
  }
}
