import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class MyData extends InheritedWidget {
  final Stream<DocumentSnapshot> stream;

  MyData({
    required this.stream,
    required Widget child,
  }) : super(child: child);

  static MyData? of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<MyData>();
  }

  @override
  bool updateShouldNotify(MyData oldWidget) {
    return stream != oldWidget.stream;
  }
}