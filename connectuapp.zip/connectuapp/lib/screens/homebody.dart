import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class homepage_body extends StatefulWidget {
  const homepage_body({super.key});

  @override
  State<homepage_body> createState() => _homepage_bodyState();
}

class _homepage_bodyState extends State<homepage_body> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
            image: DecorationImage(
            image: AssetImage("assets/images/logo1.png",), fit: BoxFit.scaleDown, opacity: 0.2, )
          ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              
      
              SizedBox(height: 70),
              const Text('Motivation for the day!',
                  style: TextStyle(
                      fontFamily: 'Poppins-SemiBold',
                      fontSize: 22,
                      color: Colors.deepPurple,
                  )),
              const SizedBox(height: 10),
              Opacity(
                opacity: 0.8,
                child: Container(
                  width: 340,
                  height: 140,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [
                          Color.fromRGBO(0, 171, 239, 1),
                          Color.fromRGBO(169, 82, 160, 1)
                        ], begin: Alignment.topLeft, end: Alignment.centerRight),
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(
                      width: 2,
                      style: BorderStyle.solid,
                    ),
                  ),
                  child:  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(height: 20),
                      Expanded(
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 40),
                          child: Text(
                            '"Inspiration does exist, but it must find you working."',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontFamily: 'Poppins-Regular',
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(bottom: 20),
                        child: Text(
                          'Pablo Picaso',
                          style: TextStyle(
                            fontFamily: 'Poppins-SemiBold',
                            fontSize: 16,
                            color: Color.fromARGB(255, 65, 65, 65),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 60),
              const Text('Up for Some Inspiration?',
                  style: TextStyle(
                fontFamily: 'Poppins-SemiBold',
                    fontSize: 22,
                    color: Colors.deepPurple,
              )
                  ),
              SizedBox(height: 14),
              Container(
                width: 310,
                height: 200,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: const Color.fromRGBO(91, 89, 90, 0.2)
                ),
                child:  Column(
                  children: [
                    SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Column(
                          children: [
                            SizedBox(height: 10),
                            CircleAvatar(
                              radius: 24,
                              backgroundImage: AssetImage(
                                  'assets/images/football.png'),
                            ),
                            SizedBox(height: 8),
                            CircleAvatar(
                              radius: 24,
                              backgroundImage: AssetImage(
                                  'assets/images/music.png'),
                            ),
                            SizedBox(height: 8),
                            CircleAvatar(
                              radius: 24,
                              backgroundImage: AssetImage(
                                  'assets/images/gym.png'),
                            )
                          ],
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(height: 10),
                            Text('football any1?',
                                style: TextStyle(
                                  fontFamily: 'Poppins-Medium',
                                )),
                            Text('@pruthidev',
                                style: TextStyle(
                                  fontFamily: 'Poppins-Regular',
                                )),
                            SizedBox(height: 10),
                            Text('studio jam!!',
                                style: TextStyle(
                                  fontFamily: 'Poppins-Medium',
                                )),
                            Text('@musuclober',
                                style: TextStyle(
                                  fontFamily: 'Poppins-Regular',
                                )),
                            SizedBox(height: 10),
                            Text('gym lesgo',
                                style: TextStyle(
                                  fontFamily: 'Poppins-Medium',
                                )),
                            Text('@gymerone',
                                style: TextStyle(
                                  fontFamily: 'Poppins-Regular',
                                ))
                          ],
                        ),
                        Column(
                          children: [
                            Text('4:41 PM'),
                            SizedBox(height: 30),
                            Text('3:59 PM'),
                            SizedBox(height: 30),
                            Text('10:21 PM')
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}