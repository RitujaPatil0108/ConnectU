import 'package:connectuapp/models/ChatRoomModel.dart';
import 'package:connectuapp/models/Users.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class ChatRoomPage extends StatefulWidget {
   
  @override
  State<ChatRoomPage> createState() => _ChatRoomPageState();
}

class _ChatRoomPageState extends State<ChatRoomPage> 
{
  String uid = FirebaseAuth.instance.currentUser!.uid.toString();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 118, 45, 130),
        title: Text("Chat"),
      ),
      body: SafeArea(
        child: Container(
          child: Column(
            children: [
              // This is where the chats will go
              Expanded(
                child: Container()
              ),
              Container(
                color: Colors.grey[200],
                padding: EdgeInsets.symmetric(
                  horizontal: 15,
                  vertical: 5,
                ),

                child: Row(children: [
                  Flexible(
                    child: TextField(
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: "Enter message",
                      ),
                    ),
                    ),


                    IconButton(
                      onPressed: (){}, 
                      icon: Icon(Icons.send_outlined, 
                      color: Theme.of(context).colorScheme.secondary,),
                    )
                ]),
              ),
              
            ],
          ),
        ),
      ),
    );
  }
}