import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectuapp/models/interests.dart';
import 'package:connectuapp/reusable_widgets/reusable_widget.dart';
import 'package:connectuapp/screens/home_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class InterestDisplay extends StatefulWidget 
{
  @override
  State<InterestDisplay> createState() => _InterestDisplayState();
}

class _InterestDisplayState extends State<InterestDisplay> 
{
  String uid = FirebaseAuth.instance.currentUser!.uid.toString();
  List<dynamic> options = [
    Interest(interest: 'Singing'),
    Interest(interest: 'Playing Instruments'),
    Interest(interest: 'Dancing'),
    Interest(interest: 'Coding'),
    Interest(interest: 'Are & Craft'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('MultiSelect Options'),
      ),
      body: ListView.builder(
        itemCount: options.length,
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
              title: Text(options[index].interest),
              onTap: () {
                setState(() {
                  options[index].isSelected = !options[index].isSelected;
                });
              },
              trailing: options[index].isSelected
                  ? Icon(Icons.check_circle, color: Colors.green)
                  : Icon(Icons.circle_outlined),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          saveSelectedOptions();
        },
        child: Icon(Icons.save),
      ),
    );
  }

  void saveSelectedOptions() 
  {
    List selectedInterests = options.where((option) => option.isSelected).map((option) => option.interest).toList();
    // Save the selectedOptions list to Firebase using your preferred Firebase implementation
    // For example, using Firebase Firestore:
    FirebaseFirestore.instance.collection('users').doc(uid).update({
       'options': selectedInterests,
    });
    Navigator.push(context, MaterialPageRoute(builder: (context) => HomeScreen()));
  }
}