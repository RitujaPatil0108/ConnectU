import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectuapp/models/Users.dart';
import 'package:connectuapp/screens/edituser_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

import '../reusable_widgets/reusable_widget.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  String uid = FirebaseAuth.instance.currentUser!.uid.toString();
  String email = FirebaseAuth.instance.currentUser!.email.toString();

  Stream<QuerySnapshot>? _searchResults;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        backgroundColor: Color.fromARGB(255, 118, 45, 130),
      ),
      body: Center(
        child: Container(
            decoration: BoxDecoration(
              image: DecorationImage(
              image: AssetImage("assets/images/logo1.png",), fit: BoxFit.scaleDown, opacity: 0.2, )
            ),
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: Container(
                child: Padding(
              padding: EdgeInsets.fromLTRB(0, 5, 20, 0),
              child: Column(
                children: <Widget>[
                  Image.asset("assets/images/logo1.png", height: 70, width: 70),
                  const SizedBox(
                    height: 10,
                  ),
                  Text(
                    "ConnectU",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  Container(
                      child: StreamBuilder<QuerySnapshot>(
                    stream: FirebaseFirestore.instance
                        .collection('users')
                        .where('uid', isEqualTo: uid)
                        .snapshots(),
                    builder: (context, snapshot) {
                      if (snapshot.hasError) {
                        return Center(
                          child: Text('Error: ${snapshot.error}'),
                        );
                      }
                      if (!snapshot.hasData) {
                        return Center(
                          child: Text('No Data Found!'),
                        );
                      }
                      List<Users> users = snapshot.data!.docs
                          .map((doc) =>
                              Users.fromMap(doc.data() as Map<String, dynamic>))
                          .toList();
      
                      return ListView.builder(
                          shrinkWrap: true,
                          itemCount: users.length,
                          itemBuilder: (context, index) {
                            final user = users[index];
                            return Column(
                              children: <Widget>[
                                CircleAvatar(
                                  radius: 50,
                                  backgroundImage: NetworkImage(user.imageUrl),
                                ),
                                SizedBox(
                                  height: 15,
                                ),
                                Text(user.name,
                                    style: TextStyle(
                                        fontSize: 30,
                                        fontWeight: FontWeight.w700,
                                        color:
                                            Color.fromARGB(224, 109, 106, 106))),
                                SizedBox(
                                  height: 20,
                                ),
                                Center(child: Text("username", style: TextStyle(fontSize: 15))),
                                SizedBox(height: 5,),
                                Container(
                                  decoration: BoxDecoration(
                                    color: Colors.grey.withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  height: 50,
                                  width: 300,
                                  child: Padding(
                                    padding: const EdgeInsets.fromLTRB(20, 12, 0, 0),
                                    child: Text(
                                      user.username,
                                      style: TextStyle(
                                        fontSize: 20,
                                        color: Color.fromARGB(255, 57, 56, 56),
                                        fontStyle: FontStyle.italic,
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Center(child: Text("Phone", style: TextStyle(fontSize: 15))),
                                SizedBox(height: 5,),
                                Container(
                                  decoration: BoxDecoration(
                                    color: Colors.grey.withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  height: 50,
                                  width: 300,
                                  child: Padding(
                                    padding: const EdgeInsets.fromLTRB(20, 12, 0, 0),
                                    child: Text(
                                      user.phone,
                                      style: TextStyle(
                                        fontSize: 20,
                                        color: Color.fromARGB(255, 57, 56, 56),
                                        fontStyle: FontStyle.italic,
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Center(child: Text("Age", style: TextStyle(fontSize: 15))),
                                SizedBox(height: 5,),
                                Container(
                                  decoration: BoxDecoration(
                                    color: Colors.grey.withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  height: 50,
                                  width: 300,
                                  child: Padding(
                                    padding: const EdgeInsets.fromLTRB(20, 12, 0, 0),
                                    child: Expanded(
                                      child: Text(
                                        overflow: TextOverflow.visible,
                                        // location
                                        user.age,
                                        style: TextStyle(
                                          fontSize: 20,
                                          color: Color.fromARGB(255, 57, 56, 56),
                                          fontStyle: FontStyle.italic,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            );
                          });
                    },
                  )),
                  SizedBox(
                    height: 20,
                  ),
                  Container(
                    height: 50,
                    width: 200,
                    decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [
                      Color.fromRGBO(0, 171, 239, 1),
                      Color.fromRGBO(169, 82, 160, 1)
                    ])),
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        primary: Colors.transparent,
                      ),
                      onPressed: () => {
                        Navigator.push(
                        context, MaterialPageRoute(builder: (context) => EditProfileScreen())),
                      },
                      icon: Icon(Icons.edit_outlined),
                      label: Text("Edit Profile"),
                    ),
                  ),
                ],
              ),
            ))),
      ),
    );
  }
}
