import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectuapp/models/interests.dart';
import 'package:connectuapp/reusable_widgets/reusable_widget.dart';
import 'package:connectuapp/screens/home_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class InterestDisplay extends StatefulWidget {
  @override
  State<InterestDisplay> createState() => _InterestDisplayState();
}

List<String> selectedInterests = [];

class _InterestDisplayState extends State<InterestDisplay> {
  String uid = FirebaseAuth.instance.currentUser!.uid.toString();

  final kInnerDecoration = BoxDecoration(
  color: Colors.white,
  border: Border.all(color: Colors.white),
  borderRadius: BorderRadius.circular(32),
);


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Interests'),
      ),
      body: Center(
        child: GridView.count(
          crossAxisCount: 3,
          children: List.generate(interests.length, (index) {
            return GestureDetector(
              onTap: () {
                setState(() {
                  if (selectedInterests.contains(interests[index])) {
                    selectedInterests.remove(interests[index]);
                  } else {
                    selectedInterests.add(interests[index]);
                  }
                });
              },
              child: Opacity(
                opacity: 0.8,
                child: Container(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color:
                          Colors.transparent, // Set border color to transparent
                    ),
                    borderRadius: BorderRadius.circular(30),
              
                    shape: BoxShape.rectangle,
                    // gradient: LinearGradient(colors: [
                    //   Color.fromRGBO(0, 171, 239, 1),
                    //   Color.fromRGBO(169, 82, 160, 1)
                    // ], begin: Alignment.topLeft, end: Alignment.centerRight),
                    
                    color: selectedInterests.contains(interests[index])
                        ? Colors.blue
                        : Color.fromARGB(255, 176, 64, 180),
                  ),
                  margin: EdgeInsets.all(8.0),
                  child: Center(
                    child: Text(
                      interests[index],
                      style: TextStyle(
                        fontSize: 18.0,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
            );
          }),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          saveSelectedOptions();
          print('Selected Interests: $selectedInterests');
          // Add your logic to handle the selected interests here
        },
        child: Icon(Icons.done),
      ),
    );
  }

  void saveSelectedOptions() {
    // List selectedInterests1 = selectedInterests.where((option) => option.isSelected).map((option) => option.interest).toList();
    // // Save the selectedOptions list to Firebase using your preferred Firebase implementation
    // // For example, using Firebase Firestore:
    FirebaseFirestore.instance.collection('users').doc(uid).update({
      'options': selectedInterests,
    });
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => HomeScreen()));
  }
}

List<String> interests = [
  'Football',
  'Swimming',
  'Singing',
  'Guitar',
  'Keyboard',
  'Books',
  'Cooking',
  'Travel',
  'Fashion',
  'Coding',
  'Photography',
  'Dancing',
  'Art & Craft',
  'Movie Nights',
  'Graphic Designing'
];
