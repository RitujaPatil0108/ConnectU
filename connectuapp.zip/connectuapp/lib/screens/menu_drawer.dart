import 'dart:async';
import 'package:connectuapp/models/Users.dart';
import 'package:connectuapp/screens/deleteuser_screen.dart';
import 'package:connectuapp/screens/profile_screen.dart';
import 'package:connectuapp/screens/signin_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class MenuDrawer extends StatelessWidget {
  String uid = FirebaseAuth.instance.currentUser!.uid.toString();
  String email = FirebaseAuth.instance.currentUser!.email.toString();

  Stream<QuerySnapshot>? _searchResults;

  MenuDrawer({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Drawer(
        child: Container(
      decoration: BoxDecoration(
          gradient: LinearGradient(colors: [
        Color.fromRGBO(0, 171, 239, 1),
        Color.fromRGBO(169, 82, 160, 1)
      ], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
      child: Column(
        children: [
          const SizedBox(
            height: 15,
          ),
          Image.asset("assets/images/logo1.png",
              height: 100, width: 100, color: Colors.white),
          const SizedBox(
            height: 8,
          ),
          ListTile(
            leading: Icon(
              Icons.person_outlined,
              color: Colors.white,
            ),
            title: Text(
              'Profile',
              style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 20),
            ),
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => ProfileScreen()));
            },
          ),
          ListTile(
            leading: Icon(
              Icons.settings_outlined,
              color: Colors.white,
            ),
            title: Text(
              'Settings',
              style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 20),
            ),
            onTap: () {
              print("Settings pressed");

              // Navigator.push(context,
              //     MaterialPageRoute(builder: (context) => SettingsScreen()));
            },
          ),
          ListTile(
            leading: Icon(
              Icons.logout_outlined,
              color: Colors.white,
            ),
            title: Text(
              'Logout',
              style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 20),
            ),
            onTap: () {
              FirebaseAuth.instance.signOut();
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => SignInScreen()));
            },
          ),
          ListTile(
            leading: Icon(
              Icons.delete_outline,
              color: Colors.white,
            ),
            title: Text(
              'Delete Account',
              style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 20),
            ),
            onTap: () async {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => DeleteUserScreen()));
            },
          ),
          SizedBox(
            height: 280,
          ),
          Expanded(
              child: StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('users')
                .where('uid', isEqualTo: uid)
                .snapshots(),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Center(
                  child: Text('Error: ${snapshot.error}'),
                );
              }
              if (!snapshot.hasData) {
                return Center(
                  child: Text('No Data Found!'),
                );
              }
              List<Users> users = snapshot.data!.docs
                  .map((doc) =>
                      Users.fromMap(doc.data() as Map<String, dynamic>))
                  .toList();

              return ListView.builder(
                  shrinkWrap: true,
                  itemCount: users.length,
                  itemBuilder: (context, index) {
                    final user = users[index];
                    print(user.imageUrl);
                    print("\n \nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
                    print(user.phone);
                    String test = user.imageUrl;
                    print(test);
                    print("\n XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
                    return UserAccountsDrawerHeader(
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                      ),
                      accountName: Text(user.username),
                      accountEmail: Text(email),
                      currentAccountPicture: CircleAvatar(
                        backgroundImage: NetworkImage(user.imageUrl),
                      ),
                    );
                  });
            },
          )),
        ],
      ),
    ));
  }
}
