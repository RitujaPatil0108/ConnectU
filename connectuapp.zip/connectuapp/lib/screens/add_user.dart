import 'dart:io';
import 'package:connectuapp/models/Users.dart';
import 'package:connectuapp/models/interests.dart';
import 'package:connectuapp/screens/interestdisplay_screen.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_geocoder/geocoder.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';

class AddUser extends StatefulWidget {
  const AddUser({super.key});

  @override
  State<AddUser> createState() => _AddUserState();
}

class _AddUserState extends State<AddUser> {
  DatabaseReference ref = FirebaseDatabase.instance.ref().child('users');
  String uid = FirebaseAuth.instance.currentUser!.uid.toString();
  String email = FirebaseAuth.instance.currentUser!.email.toString();

  final _formKey = GlobalKey<FormState>();
  late String _uid = uid;
  late String _username;
  late String _name;
  late String _age;
  late String _email = email;
  late String _phone;
  late double _latitude;
  late double _longitude;
  late String _address;
  late String _imageUrl;
  late List _options = [] as List;
  //Interest(interest: " ", isSelected: false) as List<Interest>; 

  String stAddress = '';
  String stlatitude = '';
  String stlongitude = '';

  //Function for Get Current Location
  Future<Position> _getCurrentLocation() async {
    /*
    1. Check if Location Services are on or not
    2. Check if the app has permissions, if not ask for permissions
    3. Return the current location
    */

    //Check if the Location is Turned On or Not
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();

    //Return error if location is turned off
    if (!serviceEnabled) {
      return Future.error("Locations services are disabled");
    }

    //Check if the app has permission to access location
    LocationPermission permission = await Geolocator.checkPermission();

    //Check if permission is allowed
    if (permission == LocationPermission.denied) {
      //Request permission if it is denied by default
      permission = await Geolocator.requestPermission();

      //Log an Error if users denies permission
      if (permission == LocationPermission.denied) {
        return Future.error("Location permissions are denied");
      }
    }

    //Log an Error if permission denied forever
    if (permission == LocationPermission.deniedForever) {
      return Future.error('Location permission are permanently denied.');
    }

    //Return the Current Location
    return await Geolocator.getCurrentPosition();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Color.fromARGB(255, 118, 45, 130),
        elevation: 0,
        title: const Text(
          "Register User",
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              Container(
                width: 56,
                height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.deepPurpleAccent,
                ),
                child: IconButton(
                  icon: Icon(Icons.person_outlined),
                  color: Colors.white,
                  onPressed: () async {
                    // Step1: Pick image
                    ImagePicker imagePicker = ImagePicker();
                    XFile? file =
                        await imagePicker.pickImage(source: ImageSource.gallery);
                    print('${file?.path}');
                    print("Camera pressed");

                    if (file == null) return;
                    String uniqueFileName =
                        DateTime.now().millisecondsSinceEpoch.toString();

                    // Step 2: Upload image to firebase storage
                    //Get a reference to storage root
                    Reference referenceRoot = FirebaseStorage.instance.ref();
                    Reference referenceDirImages =
                        referenceRoot.child('images');
                    //Create a reference for the image to be stored
                    Reference referenceImageToUpload =
                        referenceDirImages.child(uniqueFileName);

                    try {
                      //Store the file
                      await referenceImageToUpload.putFile(File(file.path));
                      //Success: get the download URL
                      _imageUrl = await referenceImageToUpload.getDownloadURL();
                      print("Printing image url");
                      print(_imageUrl);
                    } catch (error) {
                      print(error);
                    }

                  },

                ),
              ),
              Container(
                margin: EdgeInsets.all(16),
                child: TextFormField(
                  cursorColor: Color.fromARGB(255, 3, 1, 1),
                  decoration: InputDecoration(
                    labelStyle: TextStyle(
                        color:
                            Color.fromARGB(255, 94, 92, 92).withOpacity(0.5)),
                    labelText: 'User name',
                    filled: true,
                    floatingLabelBehavior: FloatingLabelBehavior.never,
                    fillColor:
                        Color.fromARGB(255, 187, 177, 177).withOpacity(0.3),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                        borderSide: const BorderSide(
                            width: 0, style: BorderStyle.none)),
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Please enter username';
                    }
                    return null;
                  },
                  onSaved: (value) {
                    _username = value!;
                  },
                ),
              ),
              Container(
                margin: EdgeInsets.all(16),
                child: TextFormField(
                  cursorColor: Color.fromARGB(255, 3, 1, 1),
                  decoration: InputDecoration(
                    labelStyle: TextStyle(
                        color:
                            Color.fromARGB(255, 94, 92, 92).withOpacity(0.5)),
                    labelText: 'Full Name',
                    filled: true,
                    floatingLabelBehavior: FloatingLabelBehavior.never,
                    fillColor:
                        Color.fromARGB(255, 187, 177, 177).withOpacity(0.3),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                        borderSide: const BorderSide(
                            width: 0, style: BorderStyle.none)),
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Please enter your name';
                    }
                    return null;
                  },
                  onSaved: (value) {
                    _name = value!;
                  },
                ),
              ),
              Container(
                margin: EdgeInsets.all(16),
                child: TextFormField(
                  cursorColor: Color.fromARGB(255, 3, 1, 1),
                  decoration: InputDecoration(
                    labelStyle: TextStyle(
                        color:
                            Color.fromARGB(255, 94, 92, 92).withOpacity(0.5)),
                    labelText: 'Age',
                    filled: true,
                    floatingLabelBehavior: FloatingLabelBehavior.never,
                    fillColor:
                        Color.fromARGB(255, 187, 177, 177).withOpacity(0.3),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                        borderSide: const BorderSide(
                            width: 0, style: BorderStyle.none)),
                  ),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Please enter age';
                    }
                    if (double.tryParse(value) == null) {
                      return 'Please enter valid age';
                    }
                    return null;
                  },
                  onSaved: (value) {
                    _age = double.parse(value!).toString();
                  },
                ),
              ),
              Container(
                margin: EdgeInsets.all(16),
                child: TextFormField(
                    cursorColor: Color.fromARGB(255, 3, 1, 1),
                    decoration: InputDecoration(
                      labelStyle: TextStyle(
                          color:
                              Color.fromARGB(255, 94, 92, 92).withOpacity(0.5)),
                      labelText: 'Phone',
                      filled: true,
                      floatingLabelBehavior: FloatingLabelBehavior.never,
                      fillColor:
                          Color.fromARGB(255, 187, 177, 177).withOpacity(0.3),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: const BorderSide(
                              width: 0, style: BorderStyle.none)),
                    ),
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Please enter phone number';
                      }
                      if (int.tryParse(value) == null) {
                        return 'Please enter valid phone number';
                      }
                      return null;
                    },
                    onSaved: (value) {
                      _phone = int.parse(value!).toString();
                    }),
              ),
              Column(
                children: <Widget>[
                  SizedBox(height: 10),
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10.0),                     
                      color: Color.fromARGB(255, 187, 177, 177).withOpacity(0.3),
                    ),
                    padding: EdgeInsets.all(12.0),
                    child: Row(
                      children: [
                        Icon(
                          Icons.gps_fixed,
                          color: Colors.grey,
                        ),
                        SizedBox(width: 8.0),
                        Text(
                          'Latitude: $stlatitude',
                          style: TextStyle(
                            fontSize: 16.0,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 10),
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10.0),
                      color: Color.fromARGB(255, 187, 177, 177).withOpacity(0.3),
                    ),
                    padding: EdgeInsets.all(12.0),
                    child: Row(
                      children: [
                        Icon(
                          Icons.gps_fixed,
                          color: Colors.grey,
                        ),
                        SizedBox(width: 8.0),
                        Text(
                          'Longitude: $stlongitude',
                          style: TextStyle(
                            fontSize: 16.0,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 10),
                  Container(
                    child: ElevatedButton(
                      onPressed: () {
                        //The Function To Get The Location is called
                        _getCurrentLocation().then((value) async {
                          _latitude = value.latitude;
                          _longitude = value.longitude;
                          print("XXXXXXXXXX \n\n\n");
                          print(
                              'Latitude: $_latitude , Longitude: $_longitude');
                          print("XXXXXXXXXX");
                        });

                        setState(() {
                          stlatitude = _latitude.toString();
                          stlongitude = _longitude.toString();
                        });
                      },
                      child: const Text('Get Current Location'),
                    ),
                  ),
                ],
              ),
              Container(
                child: Column(
                  children: <Widget>[
                    SizedBox(height: 10),
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8.0),
                        color: Color.fromARGB(255, 187, 177, 177).withOpacity(0.3),
                      ),
                      padding: EdgeInsets.all(12.0),
                      child: Row(
                        children: [
                          Icon(
                            Icons.location_on_outlined,
                            color: Colors.grey,
                          ),
                          SizedBox(width: 8.0),
                          Expanded(
                            child: Text(
                              stAddress,
                              style: TextStyle(
                                fontSize: 16.0,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 10),
                    ElevatedButton(
                      onPressed: () async {
                        final coordinates = new Coordinates(
                            _latitude as double?, _longitude as double?);
                        var address = await Geocoder.local
                            .findAddressesFromCoordinates(coordinates);
                        var first = address.first;
                        _address = first.addressLine.toString();
                        print("ADDRESS");
                        print(_address);
                        print("ADDRESS");

                        setState(() {
                          stAddress = _address;
                        });
                      },
                      child: const Text('Get Address'),
                    ),
                  ],
                ),
              ),
              
              SizedBox(height: 16.0),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    onPressed: _resetForm,
                    child: Text('Reset'),
                  ),
                  ElevatedButton(
                    onPressed: () => {
                      _submitForm(),
                      // Show a success message
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Registration successful')),
                      ),
                      //           Navigator.push(
                      // context, MaterialPageRoute(builder: (context) => HomeScreen())),
                    },
                    child: Text('Add'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _resetForm() {
    _formKey.currentState!.reset();
  }

  void _submitForm() {
    print("Check 1");
    print(_uid);
    if (_formKey.currentState!.validate()) {
      print("Uid submitted!");
      print("CHeck 2");
      _formKey.currentState!.save();
      // TODO: Add user to database
      Users users = Users(
        uid: _uid,
        imageUrl: _imageUrl,
        username: _username,
        name: _name,
        age: _age,
        email: _email,
        phone: _phone,
        latitude: _latitude,
        longitude: _longitude,
        address: _address,
        options: _options,
      );
      // Add product data to Cloud Firestore
      FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .set(users.toMap())
          .catchError((error) => print('Failed to add users: $error'));
    }
   // Navigator.push(context, MaterialPageRoute(builder: (context) => HomeScreen()));
    Navigator.push(context, MaterialPageRoute(builder: ((context) => InterestDisplay())));
  }
}
