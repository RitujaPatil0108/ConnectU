import 'package:firebase_auth/firebase_auth.dart';
import 'package:connectuapp/reusable_widgets/reusable_widget.dart';
import 'package:connectuapp/screens/home_screen.dart';
import 'package:connectuapp/screens/reset_password.dart';
import 'package:connectuapp/screens/signup_screen.dart';
import 'package:flutter/material.dart';

class SignInScreen extends StatefulWidget {
  const SignInScreen({Key? key}) : super(key: key);

  @override
  _SignInScreenState createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  TextEditingController _passwordTextController = TextEditingController();
  TextEditingController _emailTextController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.fromLTRB(
                20, MediaQuery.of(context).size.height * 0.1, 20, 0),
            child: Column(
              children: <Widget>[
                logoWidget("assets/images/logo1.png"),
                const SizedBox(
                  height: 10,
                ),
                const Text("ConnectU",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 50,
                        color: Color.fromARGB(255, 7, 0, 0))),
                const SizedBox(
                  height: 20,
                ),
                Container(
                  child: reusableTextField("Enter email", Icons.person_outline,
                      false, _emailTextController),
                ),
                const SizedBox(
                  height: 20,
                ),
                reusableTextField("Enter Password", Icons.lock_outline, true,
                    _passwordTextController),
                const SizedBox(
                  height: 5,
                ),
                forgetPassword(context),
                firebaseUIButton(context, "Login", () {
                  FirebaseAuth.instance
                      .signInWithEmailAndPassword(
                          email: _emailTextController.text,
                          password: _passwordTextController.text)
                      .then((value) {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => HomeScreen()));
                        // Show a success message
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Login Successful')),
                );
                  }).onError((error, stackTrace) {
                    print("Error ${error.toString()}");
                    // Show a failure message
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(':ogin failed')),
                );
                  });
                }),
                const Text("~ or continue with ~",style: TextStyle(color: Colors.grey)),
                const SizedBox(
                  height: 5,
                ),
                Center(child: Row(
                  
                  children: [
                    Padding(padding: EdgeInsets.fromLTRB(45, 0, 80, 0)),
                    CircleAvatar(
                      backgroundColor: Colors.white60,
                      radius: 20,
                      backgroundImage: AssetImage("assets/images/google.png"),
                    ),
                    const SizedBox(
                  width: 10,
                ),
                    CircleAvatar(
                      backgroundColor: Colors.white60,
                      radius: 20,
                      backgroundImage: AssetImage("assets/images/f.png"),
                    ),
                  ],
                )),
                const SizedBox(
                  height: 10,
                ),
                signUpOption()
              ],
            ),
          ),
        ),
      ),
    );
  }

  Row signUpOption() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text("New User?", style: TextStyle(color: Colors.grey)),
        GestureDetector(
          onTap: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => SignUpScreen()));
          },
          child: const Text(
            "Create account",
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
          ),
        )
      ],
    );
  }

  Widget forgetPassword(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: 35,
      alignment: Alignment.bottomRight,
      child: TextButton(
        child: const Text(
          "Forgot Password?",
          style: TextStyle(color: Color.fromARGB(179, 94, 94, 94)),
          textAlign: TextAlign.right,
        ),
        onPressed: () => Navigator.push(
            context, MaterialPageRoute(builder: (context) => ResetPassword())),
      ),
    );
  }
}
