import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class GoogleMapScreen extends StatefulWidget {
  const GoogleMapScreen({super.key});

  @override
  State<GoogleMapScreen> createState() => _GoogleMapScreenState();
}

class _GoogleMapScreenState extends State<GoogleMapScreen> {
  Completer<GoogleMapController> _controller = Completer();

  //This is the users currenct location, where the map opens up
  static final CameraPosition _location = const CameraPosition(
    target: LatLng(28.574970, 77.208500),
    zoom: 14,
  );

  List<Marker> _marker = [];
  List<Marker> _list = const [
    Marker(
        markerId: MarkerId('1'),
        position: (LatLng(28.574970, 77.208500)),
        infoWindow: InfoWindow(
            //Replace Current Location with name of the user
            title: "My Current Location")),
    Marker(
        markerId: MarkerId('2'),
        position: (LatLng(29.574970, 78.208500)),
        infoWindow: InfoWindow(
            //Replace Current Location with name of the user
            title: "My 2nd Location")),
    Marker(
        markerId: MarkerId('3'),
        position: (LatLng(27.574970, 76.208500)),
        infoWindow: InfoWindow(
            //Replace Current Location with name of the user
            title: "My 3rd Location"))
  ];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _marker.addAll(_list);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: GoogleMap(
            initialCameraPosition: _location,
            markers: Set.of(_marker),
            mapType: MapType.normal,
            compassEnabled: true,
            myLocationButtonEnabled: true,
            onMapCreated: (GoogleMapController controller) {
              print("Map Loaded");
              _controller.complete(controller);
            }));
  }
}
