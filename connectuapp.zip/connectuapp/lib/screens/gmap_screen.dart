import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectuapp/models/Users.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class GMapScreen extends StatefulWidget {
  const GMapScreen({super.key});

  @override
  State<GMapScreen> createState() => _GMapScreenState();
}

class _GMapScreenState extends State<GMapScreen> {
  Completer<GoogleMapController> _controller = Completer();
  String uid = FirebaseAuth.instance.currentUser!.uid.toString();
  String email = FirebaseAuth.instance.currentUser!.email.toString();
  CameraPosition? _location;
  List<Users> users = [];

  //List<Marker> _marker = [];
  List<Marker> _list = [];

  // @override
  // void initState() {
  //   // TODO: implement initState
  //   super.initState();
  //   _marker.addAll(_list);
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 118, 45, 130),
        title: const Text(
          "Nearby Users",
        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .where('uid', isEqualTo: uid)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
          List<Users> users1 = [];
          snapshot.data?.docs.forEach((doc) {
            Users currentuser =
                Users.fromMap(doc.data() as Map<String, dynamic>);
            users1.add(currentuser);
            //print("USer 1 **********");
            //print(users1[0].user.)
          });
          print("**********************");
          print(users1);
          late Users usernew;
          users1.forEach((element) {
            print(element.latitude);
            print(element.longitude);
            usernew = element;
          });
          print(usernew);

          print("USERS FROM LIST");
          print(usernew.latitude);
          print(usernew.longitude);

          //This is the users currenct location, where the map opens up
          _location = CameraPosition(
            target: LatLng(usernew.latitude, usernew.longitude),
            zoom: 14,
          );

          print("SSSSSSSSSSSSSSSS");
          print(_location);
          print("SSSSSSSSSSSSSSSSSSSS");

          return StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('users')
                //.where('email', isNotEqualTo: email)
                .where('options', isEqualTo: usernew.options)
                .snapshots(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return Center(
                  child: CircularProgressIndicator(),
                );
              }

              snapshot.data?.docs.forEach((doc) {
                Users user = Users.fromMap(doc.data() as Map<String, dynamic>);
                users.add(user);
              });

              late Users usernewmap;
              users.forEach((element) {
                print("MAAAAAAAAAAAPPP");
                print(element.name);
                print(element.latitude);
                print(element.longitude);
                usernewmap = element;
                _list.add(Marker(
                markerId: MarkerId(element.uid),
                position: LatLng(element.latitude, element.longitude),
                infoWindow: InfoWindow(title: element.name)));
            print(_list);

              });
              return GoogleMap(
                  initialCameraPosition: _location!,
                  markers: Set.of(_list),
                  mapType: MapType.normal,
                  compassEnabled: true,
                  myLocationButtonEnabled: true,
                  onMapCreated: (GoogleMapController controller) {
                    print("Map Loaded");
                    _controller.complete(controller);
                  });
            },
          );
        },
      ),
    );


  }
}
