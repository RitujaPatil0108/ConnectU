import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectuapp/models/interests.dart';
import 'package:connectuapp/screens/home_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import '../models/Users.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  DatabaseReference ref = FirebaseDatabase.instance.ref().child('users');
  String uid = FirebaseAuth.instance.currentUser!.uid.toString();
  String email = FirebaseAuth.instance.currentUser!.email.toString();

  final _formKey = GlobalKey<FormState>();
  late String _uid = uid;
  late String _username;
  late String _name;
  late String _age;
  late String _email = email;
  late String _phone;
  late double _latitude;
  late double _longitude;
  late String _address;
  late String _imageUrl;
  late List _options = [] as List;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Color.fromARGB(255, 118, 45, 130),
        elevation: 0,
        title: const Text(
          "Edit User",
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.w400),
        ),
        ),
        body: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance
              .collection('users')
              .where('uid', isEqualTo: uid)
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Center(
                child: Text('Error: ${snapshot.error}'),
              );
            }
            if (!snapshot.hasData) {
              return Center(
                child: Text('No Data Found!'),
              );
            }
            List<Users> users = snapshot.data!.docs
                .map((doc) => Users.fromMap(doc.data() as Map<String, dynamic>))
                .toList();

            return ListView.builder(
              
                shrinkWrap: true,
                itemCount: users.length,
                itemBuilder: (context, index) {
                  final user = users[index];
                  _imageUrl = user.imageUrl;
                  _latitude = user.latitude;
                  _longitude = user.longitude;
                  _address = user.address;
                  _options = user.options;
                  return Column(
                    children: [
                      SizedBox(
                        height: 20,
                      ),
                      CircleAvatar(
                                radius: 50,
                                backgroundImage: NetworkImage(user.imageUrl),
                              ),
                              SizedBox(
                                height: 15,
                              ),

                      Form(
                        key: _formKey,
                        child: ListView(
                          shrinkWrap: true,
                          children: [
                            Container(
                              margin: EdgeInsets.all(16),
                              child: TextFormField(
                                initialValue: user.username,
                                decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10))),
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Please enter username';
                                  }
                                  return null;
                                },
                                onSaved: (value) {
                                  _username = value!;
                                },
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.all(16),
                              child: TextFormField(
                                initialValue: user.name,
                                decoration: InputDecoration(
                                    //hintText: user.name,
                                    border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10))),
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Please enter your name';
                                  }
                                  return null;
                                },
                                onSaved: (value) {
                                  _name = value!;
                                },
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.all(16),
                              child: TextFormField(
                                initialValue: user.age,
                                decoration: InputDecoration(
                                    //hintText: user.age,
                                    border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10))),
                                keyboardType: TextInputType.number,
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Please enter age';
                                  }
                                  if (double.tryParse(value) == null) {
                                    return 'Please enter valid age';
                                  }
                                  return null;
                                },
                                onSaved: (value) {
                                  _age = double.parse(value!).toString();
                                },
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.all(16),
                              child: TextFormField(
                                initialValue: user.phone,
                                  decoration: InputDecoration(
                                     // hintText: user.phone,
                                      border: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(10))),
                                  keyboardType: TextInputType.number,
                                  validator: (value) {
                                    if (value!.isEmpty) {
                                      return 'Please enter phone number';
                                    }
                                    if (int.tryParse(value) == null) {
                                      return 'Please enter valid phone number';
                                    }
                                    return null;
                                  },
                                  onSaved: (value) {
                                    _phone = int.parse(value!).toString();
                                  }),
                            ),
                            Container(),
                            SizedBox(height: 16.0),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                ElevatedButton(
                                  onPressed: _resetForm,
                                  child: Text('Reset'),
                                ),
                                ElevatedButton(
                                  onPressed: () => {
                                    _submitForm(),
                                    // Show a success message
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Profile updated successfully')),
                ),
                                                                        //   Navigator.push(
                                    // context, MaterialPageRoute(builder: (context) => HomeScreen())),
                                  },
                                  child: Text('Save'),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
                });
          },
        ));
  }

  void _resetForm() {
    _formKey.currentState!.reset();
  }

  void _submitForm() {
    print("Check 1");
    print(_uid);
    if (_formKey.currentState!.validate()) {

      print("Uid submitted!");
      print("CHeck 2");
      _formKey.currentState!.save();
      // TODO: Add user to database
      Users users = Users(
        uid: _uid,
        imageUrl: _imageUrl,
        username: _username,
        name: _name,
        age: _age,
        email: _email,
        phone: _phone,
        latitude: _latitude,
        longitude: _longitude,
        address: _address,
        options: _options,
      );
       print("YYYYYYYYYYYYYY");
    print(_username);
    print("YYYYYYYYYYYY");
      // Update usser data to Cloud Firestore
      FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .update(users.toMap())
          .catchError((error) => print('Failed to update users: $error'));
    }
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => HomeScreen()));
  }
}
