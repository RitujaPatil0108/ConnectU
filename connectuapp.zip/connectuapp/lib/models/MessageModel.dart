class MessageModel
{
  String? messageid;
  String? sender;
  String? text;
  DateTime? createdon;
  bool? seen;

  MessageModel({this.messageid, this.sender, this.text, this.createdon, this.seen});

  MessageModel.fromMap(Map<String, dynamic> map)
  {
    messageid = map['messageid'];
    sender = map['sender'];
    text = map['text'];
    createdon = map['createdon'].toDate();
    seen = map['seen'];
  }

  Map<String, dynamic> toMap()
  {
    return 
    {
      'messageid': messageid,
      "sender": sender,
      'text': text,
      "createdon": createdon,
      "seen": seen,
    };
  }

}