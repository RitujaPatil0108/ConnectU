class Users {
  late String imageUrl;
  late String uid;
  late String username;
  late String name;
  late String age;
  late String email;
  late String phone;
  late double latitude;
  late double longitude;
  late String address;
  late List options;

  Users(
      {
        required this.uid,
        required this.imageUrl,
      required this.username,
      required this.name,
      required this.age,
      required this.email,
      required this.phone,
      required this.latitude,
      required this.longitude,
      required this.address,
      required this.options});

  // Convert User object to a Map object
  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'imageUrl': imageUrl,
      'username': username,
      'name': name,
      'age': age,
      'email': email,
      'phone': phone,
      'latitude': latitude,
      'longitude': longitude,
      'address': address,
      'options': options,
    };
  }

  factory Users.fromMap(Map<String, dynamic> map) {
    return Users(
        uid: map['uid'] ?? '',
        imageUrl: map['imageUrl'] ?? '',
        username: map['username'] ?? '',
        name: map['name'] ?? '',
        age: map['age'] ?? '',
        email: map['email'] ?? '',
        phone: map['phone'] ?? '',
        latitude: map['latitude'] ?? 0.0,
        longitude: map['longitude'] ?? 0.0,
        address: map['address'] ?? '',
        options: (map['options'] ?? []) as List);
  }
}
