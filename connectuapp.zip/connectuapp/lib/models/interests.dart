class Interest 
{
  String interest;
  bool isSelected;
  Interest({required this.interest, this.isSelected = false});
}